package com.example.helloabcd

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var statusText: TextView
    private lateinit var startButton: Button
    private lateinit var listenButton: Button

    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var ttsReady = false
    private var pendingListenAfterSpeech = false

    private enum class Step {
        IDLE, ASK_NAME, ASK_HOW_ARE_YOU, ASK_ABCD, FINISHED
    }

    private var step = Step.IDLE
    private var userName = ""

    private val audioPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                beginConversation()
            } else {
                statusText.text = "Microphone permission zaroori hai. Settings me permission allow kijiye."
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        startButton = findViewById(R.id.startButton)
        listenButton = findViewById(R.id.listenButton)

        tts = TextToSpeech(this, this)
        setupSpeechRecognizer()

        startButton.setOnClickListener { ensurePermissionAndStart() }
        listenButton.setOnClickListener { startListening() }
    }

    private fun ensurePermissionAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED
        ) {
            beginConversation()
        } else {
            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun beginConversation() {
        step = Step.ASK_NAME
        speakAndListen("Namaste! Aapka naam kya hai?")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            val result = tts?.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale.US
            }

            tts?.setSpeechRate(0.88f)
            tts?.setPitch(1.0f)
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit
                override fun onError(utteranceId: String?) = Unit
                override fun onDone(utteranceId: String?) {
                    if (pendingListenAfterSpeech) {
                        pendingListenAfterSpeech = false
                        runOnUiThread { startListening() }
                    }
                }
            })
        } else {
            statusText.text = "Text-to-Speech initialize nahi ho paya."
        }
    }

    private fun setupSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusText.text = "Is phone par speech recognition available nahi hai."
            return
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                statusText.text = "Main sun raha hoon..."
            }

            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() {
                statusText.text = "Aapka jawab process ho raha hai..."
            }

            override fun onError(error: Int) {
                statusText.text = "Awaaz clear nahi mili. 'Dobara Suniye' dabaiye."
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val spoken = matches?.firstOrNull()?.trim().orEmpty()
                if (spoken.isNotEmpty()) {
                    statusText.text = "Aapne kaha: $spoken"
                    handleAnswer(spoken)
                } else {
                    statusText.text = "Jawab nahi mila. Dobara boliye."
                }
            }

            override fun onPartialResults(partialResults: Bundle?) = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Boliye...")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }

        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            statusText.text = "Speech recognition start nahi ho paya: ${e.message}"
        }
    }

    private fun handleAnswer(answer: String) {
        when (step) {
            Step.ASK_NAME -> {
                userName = cleanName(answer)
                step = Step.ASK_HOW_ARE_YOU
                speakAndListen("Hello $userName, aap kaise ho?")
            }

            Step.ASK_HOW_ARE_YOU -> {
                step = Step.ASK_ABCD
                speakAndListen("Achha. Kya aap A B C D padhna chahte ho?")
            }

            Step.ASK_ABCD -> {
                if (isYes(answer)) {
                    step = Step.FINISHED
                    speakAlphabet()
                } else {
                    step = Step.FINISHED
                    speakOnly("Theek hai $userName. Jab aap padhna chahein, Start Conversation dabaiye.")
                }
            }

            else -> Unit
        }
    }

    private fun cleanName(value: String): String {
        return value
            .replace("mera naam", "", ignoreCase = true)
            .replace("hai", "", ignoreCase = true)
            .trim()
            .ifBlank { "dost" }
    }

    private fun isYes(answer: String): Boolean {
        val value = answer.lowercase(Locale.getDefault())
        val yesWords = listOf("haan", "han", "ha", "yes", "जी हाँ", "हां", "हाँ", "जी")
        return yesWords.any { value.contains(it) }
    }

    private fun speakAlphabet() {
        val alphabet = ('A'..'Z').joinToString(", ")
        statusText.text = "ABCD padh raha hoon...\n$alphabet"
        speakOnly("Chaliye shuru karte hain. $alphabet. Bahut badhiya $userName!")
    }

    private fun speakAndListen(text: String) {
        statusText.text = text
        pendingListenAfterSpeech = true
        speak(text)
    }

    private fun speakOnly(text: String) {
        statusText.text = text
        pendingListenAfterSpeech = false
        speak(text)
    }

    private fun speak(text: String) {
        if (!ttsReady) {
            statusText.text = "$text\n\nText-to-Speech tayyar ho raha hai."
            return
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "utterance-${System.currentTimeMillis()}")
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
