# Hello ABCD Android App

Voice-based Android app flow:
1. App asks: "Aapka naam kya hai?"
2. User speaks their name.
3. App says: "Hello {name}, aap kaise ho?"
4. User replies.
5. App asks: "Kya aap ABCD padhna chahte ho?"
6. If user says haan/yes, app speaks A to Z.

## Build in Android Studio
- Open the `HelloABCDApp` folder in Android Studio.
- Let Gradle sync finish.
- Connect an Android phone with USB debugging enabled, then press Run.
- Or use Build > Build APK(s) and install the generated APK on the phone.

The app needs microphone permission and Android's Speech Recognition/Text-to-Speech services.

## Build APK online (no Android Studio)
This project includes `.github/workflows/build-apk.yml`.
Upload the project to GitHub, open **Actions > Build Android APK > Run workflow**, and download the **HelloABCDApp-APK** artifact after the build completes.
See `GITHUB_BUILD_INSTRUCTIONS.md` for step-by-step instructions.
