# Build APK without Android Studio

You only need a free GitHub account and a web browser.

## 1. Create a GitHub repository
1. Open https://github.com/new
2. Repository name: `HelloABCDApp`
3. Choose **Private** if you do not want the code public.
4. Click **Create repository**.

## 2. Upload this project
1. Open the new repository.
2. Click **Add file** -> **Upload files**.
3. Upload the CONTENTS of the `HelloABCDApp` folder, not the outer ZIP itself.
4. Make sure `.github/workflows/build-apk.yml` is included.
5. Click **Commit changes**.

## 3. Build the APK
1. Open the **Actions** tab in your repository.
2. Select **Build Android APK**.
3. Click **Run workflow** -> **Run workflow**.
4. Wait for the workflow to show a green check mark.

## 4. Download the APK
1. Open the completed workflow run.
2. Scroll to **Artifacts**.
3. Download **HelloABCDApp-APK**.
4. Extract the downloaded ZIP.
5. Inside it you will find `app-debug.apk`.
6. Send that APK to your Android phone and install it.

Android may ask you to allow installation from your browser/file manager. Enable **Install unknown apps** only for the app you use to open the APK, then install.
